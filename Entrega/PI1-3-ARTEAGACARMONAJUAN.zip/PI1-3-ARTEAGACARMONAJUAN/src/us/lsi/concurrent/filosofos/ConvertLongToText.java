package us.lsi.concurrent.filosofos;

import org.jdesktop.beansbinding.Converter;

public class ConvertLongToText extends Converter<Long, String> {

	@Override
	public String convertForward(Long arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long convertReverse(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public ConvertLongToText() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}

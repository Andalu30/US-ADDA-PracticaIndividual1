package us.lsi.graphs;

public interface EdgeWeight<E> {
	
	double getWeight(E e);

}

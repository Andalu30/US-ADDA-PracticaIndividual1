package us.lsi.beans;

public class Consolas {

	public static ConsolaConVeto createConsolaConVeto() {
		return new ConsolaConVeto();
	}

	public static Consola createConsola() {
		return new Consola();
	}

}

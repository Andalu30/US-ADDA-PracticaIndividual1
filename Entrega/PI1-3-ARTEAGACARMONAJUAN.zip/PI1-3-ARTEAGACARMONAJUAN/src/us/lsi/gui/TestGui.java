package us.lsi.gui;

public class TestGui {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CelsiusConverter.create();
	}

}

package us.lsi.gui;

import java.util.List;

public interface PhoneBook {
	
	public PhoneGroups getCategories();

	public List<String> getNamesOfCategories();
}

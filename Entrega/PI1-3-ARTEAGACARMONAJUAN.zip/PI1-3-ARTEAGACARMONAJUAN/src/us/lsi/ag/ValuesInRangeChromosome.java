package us.lsi.ag;

import java.util.List;

public interface ValuesInRangeChromosome<E> extends Chromosome<List<E>> {
	
}

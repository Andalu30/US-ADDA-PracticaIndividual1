package us.lsi.ag;

/**
 * @author Miguel Toro
 * 
 * <p> Un problema general de algoritmos gen�ticos </p>
 *
 */
public interface ProblemAG {

}

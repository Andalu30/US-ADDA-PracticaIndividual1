/**
 * 
 */
/**
 * @author Miguel Toro
 *
 */
package us.lsi.astar.sudoku;